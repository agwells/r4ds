## Summary

This sentence briefly summarizes the issue.

## Minimal code example

Here is the minimum amount of code neeeded to demonstrate the issue:

```r
ggplot(...) + geom_text_repel(...)
```

Here is an image of the output produced by the code:

IMAGE

## Suggestions

This is my proposal for how to solve the issue.

## Version information

Here is the output from `sessionInfo()` in my R session:

```
Paste output here
```
