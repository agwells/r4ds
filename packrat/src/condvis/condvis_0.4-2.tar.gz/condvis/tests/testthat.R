library(testthat)
library(condvis)
test_check("condvis")
